<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Consulta de Produtos</title>
</head>
<body>
	<form name="cadastro" method="post" action="cadastrar.php">

	Codigo: <input type="text" name="codigo"></input>
	</br></br>
	
	<input type="submit" value="Pesquisar..."></input>	
		
	</form>

</body>
</html>